package main

import (
	"UniProxy/common/sysproxy"
)

func main() {
	sysproxy.ClearSystemProxy()
}
