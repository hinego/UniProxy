package sysproxy

import "testing"

func TestClearSystemProxy(t *testing.T) {
	t.Log(ClearSystemProxy())
}
