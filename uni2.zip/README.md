# UniProxy
基于 SingBox 重新实现的 V2board 潮汐客户端核心库。

## 构建
``` bash
# Windows
GOOS=windows bash build.sh
# MacOS
GOOS=darwin bash build.sh
```
## 使用
构建后替换潮汐客户端 `resources/libs/` 路径下同名二进制文件。

## Thanks
[sing-box](https://github.com/SagerNet/sing-box)
